<div class="content-wrapper">

    <div class="content-header">

        <div class="container-fluid">

            <div class="row mb-2">

                <div class="col-sm-6">

                    <h1 class="m-0"> Data Karyawan Perusahaan</h1>
                
                </div>
            
            </div>
        
        </div>
    
    </div>


    <section class="content">
        
        <div class="container-fluid">
        
            <div class="row">
          
                <div class="col-12">
            
                    <div class="card">
              
                        <div class="card-header">
                
                            <h3 class="card-title">Ringkasan Data Perusahaan</h3>

                            <div class="card-tools">
                  
                                <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                            
                                    <i class="fas fa-minus"></i>
                        
                                </button>

                                <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                            
                                    <i class="fas fa-times"></i>
                                
                                </button>
                            
                            </div>
              
                        </div>
              
                        <div class="card-body">
                        
                            <p>
                            Basis data atau database karyawan merupakan sumber informasi utama yang digunakan oleh HRD dalam mengelola administrasi personalia. Database umumnya dibuat dalam bentuk file elektronik untuk memudahkan penyimpanan dan akses.
                            </p>

                            <p>
                            
                            </p>

                            
                    
                        </div>
                        
                        <div class="card-footer">
                            
                            Karyawan Perusahaan
                        
                        </div>
                    
                    </div>
          
                </div>
        
            </div>
      
        </div>

    </section>

</div>
