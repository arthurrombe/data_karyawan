            <footer class="main-footer">

                <strong>Copyright &copy; Arthur Rombe 23 2023 .</strong> All rights reserved.

            </footer>

            <aside class="control-sidebar control-sidebar-dark">
            </aside>

        </div>
        
        <script src="<?= base_url; ?>/plugins/jquery/jquery.min.js"></script>

        <script src="<?= base_url; ?>/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>

        <script src="<?= base_url; ?>/dist/js/adminlte.min.js"></script>

    </body>

</html>